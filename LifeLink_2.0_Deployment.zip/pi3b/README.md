# LifeLink 2.0 — Raspberry Pi 3B+ Camera Substation Deployment Package

## 1. Hardware Overview & Pinout Interconnect

### Required Hardware
- **Processor Board**: Raspberry Pi 3 Model B+ (BCM2837B0 quad-core 1.4 GHz, 1 GB RAM).
- **Camera Module**: Raspberry Pi Camera Module 3 Wide NoIR (Sony IMX708 sensor, 120° FoV, IR-sensitive).
- **CSI Camera Ribbon**: Standard 15-pin 1.0mm pitch ribbon cable (connects to 15-pin CSI connector on Pi 3B+; contacts face the HDMI port).
- **IR Illumination Array**: 850 nm Infrared LED illuminator driven by an N-channel MOSFET (e.g., IRLZ44N) or constant-current driver.
- **Physical Pin Connections**:
  - Control Signal: **BCM GPIO18** (Physical Pin 12, PWM0 capable).
  - Common Ground: **GND** (Physical Pin 6, 9, 14, 20, 25, 30, 34, or 39).
  - *Caution*: Never drive high-current IR LEDs directly from Raspberry Pi GPIO pins. Use an external regulated 5V/12V power supply with common ground.
- **Network Interconnect**: Standard RJ45 Cat5e/Cat6 patch cable connecting the Pi 3B+ onboard Gigabit Ethernet (Microchip LAN7515) directly to the Raspberry Pi 5 Gigabit Ethernet port (or via an isolated medical Ethernet switch).

---

## 2. Operating System & Networking Specifications

- **Operating System**: Raspberry Pi OS Lite (Debian 12 Bookworm, 32-bit or 64-bit).
- **Dedicated Wired Ethernet**:
  - Raspberry Pi 5 Host IP: `192.168.50.1/24`
  - Raspberry Pi 3B+ Substation IP: `192.168.50.2/24`
  - Subnet Mask: `255.255.255.0` (`/24`)
  - Substation REST API Port: `5000` (`http://192.168.50.2:5000`)
- **Zero Runtime Wireless Invariant**:
  - Onboard Wi-Fi disabled via `dtoverlay=disable-wifi` in `/boot/firmware/config.txt`.
  - Onboard Bluetooth disabled via `dtoverlay=disable-bt` in `/boot/firmware/config.txt`.
  - Wireless system services (`wpa_supplicant`, `bluetooth`) deactivated and masked.

---

## 3. Substation Directory Structure

```text
pi3b/
├── camera_service.py         # Lightweight Flask REST daemon (port 5000)
├── camera_client.py          # Picamera2 wrapper with auto-fallback
├── config.py                 # Subsystem parameters, thresholds, and networking
├── ir_led_controller.py      # Thread-safe GPIO18 850nm controller with 15s watchdog
├── iris_capture.py           # Multi-frame acquisition, quality ranking, LED sync
├── photo_capture.py          # Portrait photo acquisition (IR LED strictly OFF)
├── quality.py                # ISO/IEC 29794-6 iris image quality metrics
├── quality_checker.py        # Quality evaluation wrapper
├── usb_communication.py      # Structured JSON formatting & protocol helper
├── main.py                   # Service launcher entry point
├── verify_camera.py          # Local hardware diagnostic verification tool
├── requirements.txt          # Python dependencies
├── install.sh                # Automated installation script
├── systemd/
│   └── lifelink-camera.service # Systemd daemon definition
└── README.md                 # Deployment documentation
```

---

## 4. Installation & Deployment Instructions

Execute the automated installer as root on the Raspberry Pi 3B+:

```bash
cd pi3b
sudo bash install.sh
```

### Automated Actions Executed by `install.sh`:
1. Installs native APT packages: `python3-picamera2`, `python3-opencv`, `python3-gpiozero`, `python3-flask`, `libcamera-apps`, and `gpiod`.
2. Adds `dtoverlay=disable-wifi` and `dtoverlay=disable-bt` to `/boot/firmware/config.txt` (or `/boot/config.txt`).
3. Configures static IP `192.168.50.2/24` on interface `eth0` via NetworkManager (`nmcli`) with fallback to `/etc/network/interfaces.d/eth0`.
4. Deploys the camera subsystem files to `/opt/lifelink-camera`.
5. Sets non-root service user permissions (`video`, `gpio`, `dialout`).
6. Registers, configures, and enables the `lifelink-camera.service` systemd daemon.
7. Explicitly asserts GPIO18 state to OUTPUT LOW (OFF).

Reboot the Raspberry Pi 3B+ after initial installation:
```bash
sudo reboot
```

---

## 5. Startup & Operational Invariants

1. **Automatic Daemon Startup**:
   - The Raspberry Pi 3B+ boots and initializes `eth0` with static IP `192.168.50.2`.
   - `lifelink-camera.service` starts automatically, binding to `0.0.0.0:5000`.
   - The camera service enters `STATE_IDLE`.
2. **Strict Invariant — Zero Auto-Capture**:
   - The camera **NEVER** captures frames or illuminates the IR LED upon boot, network link reconnect, or idle state.
   - Captures are triggered exclusively by explicit authenticated clinical commands (`POST /api/v1/camera/iris/capture`) originating from the Pi 5 terminal.
3. **IR LED Illumination Safety Invariant**:
   - The 850nm NIR LED remains **strictly OFF** when idle.
   - The LED is activated only during active iris scans and extinguished immediately upon frame acquisition.
   - A hardware/software safety watchdog timer forcefully shuts off the LED after **15 seconds** under any error, cancellation, or network timeout condition.
   - Ordinary patient portrait captures (`/api/v1/camera/photo/capture`) keep the IR LED **strictly OFF**.

---

## 6. Diagnostic & Health Verification Commands

### Run Local Hardware Diagnostics:
```bash
python3 /opt/lifelink-camera/verify_camera.py
```

### Check Systemd Service Status:
```bash
sudo systemctl status lifelink-camera.service
```

### Query Camera & LED Health (from Pi 5 or Pi 3B+):
```bash
curl http://192.168.50.2:5000/health
curl http://192.168.50.2:5000/camera/led/status
```

Expected response:
```json
{
  "camera_state": "IDLE",
  "led_active": false,
  "service": "LifeLink 2.0 Wired Camera Service",
  "device": "RaspberryPi-3B-Plus-CameraModule3-NoIR",
  "transport": "Wired-Ethernet",
  "status": "ready"
}
```

### Trigger Test Iris Scan with Token:
```bash
curl -X POST http://192.168.50.2:5000/api/v1/camera/iris/capture \
     -H "Content-Type: application/json" \
     -H "X-Camera-Token: lifelink-wired-internal-camera-token" \
     -d '{"eye_side": "OD"}'
```

---

## 7. Troubleshooting & Diagnostics

| Symptom | Root Cause | Remediation |
|:---|:---|:---|
| Pi 5 cannot ping `192.168.50.2` | Ethernet link down or IP mismatch | Check RJ45 link LEDs on Pi 3B+ and Pi 5. Verify `ip addr show eth0`. |
| `rpicam-hello --list-cameras` shows no cameras | CSI ribbon cable loose or inverted | Reseat 15-pin ribbon cable; silver pins face HDMI port on Pi 3B+. |
| Camera service returns 401 Unauthorized | Missing or mismatched security token | Check `CAMERA_API_TOKEN` matches in `/etc/lifelink/lifelink.env` and systemd unit. |
| IR LED fails to illuminate during scan | Inverted driver logic or ungrounded MOSFET | Verify active-high logic (`IR_LED_ACTIVE_HIGH=true`) and ensure common GND between Pi 3B+ and LED PSU. |
| Iris image fails quality check repeatedly | Lens out of focal distance | Adjust M12 manual focus ring for optimal acuity at 12–15 cm clinical distance. |

