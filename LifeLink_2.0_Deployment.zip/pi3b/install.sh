#!/usr/bin/env bash
# ==============================================================================
# LifeLink 2.0 - Raspberry Pi 3 Model B+ Camera & IR LED Setup Script
# Configures Dedicated Wired Ethernet (192.168.50.2/24), GPIO18 IR LED controller,
# Picamera2 / libcamera camera stack, disables Wi-Fi/Bluetooth, and registers
# the systemd daemon.
# Idempotent and preserves existing operating system configurations with backups.
# ==============================================================================

set -euo pipefail

INSTALL_DIR="/opt/lifelink-camera"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "================================================================="
echo " LifeLink 2.0: Raspberry Pi 3B+ Camera Substation Installation"
echo " Target: Raspberry Pi 3 Model B+ (Debian Bookworm / Bullseye)"
echo " Network: Dedicated Wired Ethernet (192.168.50.2/24)"
echo "================================================================="

# 1. Verify root execution
if [ "$EUID" -ne 0 ]; then
    echo "[-] Error: Please run this installation script as root (e.g., sudo bash install.sh)"
    exit 1
fi

# 2. Check architecture & OS
echo "[1/8] Inspecting hardware and operating system..."
ARCH="$(uname -m)"
echo "[+] Detected Architecture: $ARCH"
if [[ "$ARCH" != "armv7l" ]] && [[ "$ARCH" != "aarch64" ]]; then
    echo "[!] Note: Host architecture ($ARCH) is not standard Raspberry Pi 3B+ (armv7l/aarch64)."
    echo "    Continuing installation in simulation/test mode."
fi

# 3. Install required system packages
echo "[2/8] Installing system packages via apt..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-venv \
    python3-gpiozero \
    python3-picamera2 \
    python3-opencv \
    python3-numpy \
    python3-flask \
    libcamera-apps \
    gpiod \
    curl \
    net-tools

# 4. Enforce Zero-Wireless Invariant (Disable Onboard Wi-Fi and Bluetooth)
echo "[3/8] Enforcing zero-wireless hardware policy (disabling Wi-Fi & Bluetooth)..."

# Locate config.txt (Debian Bookworm uses /boot/firmware/config.txt; Bullseye uses /boot/config.txt)
BOOT_CONFIG="/boot/firmware/config.txt"
if [ ! -f "$BOOT_CONFIG" ]; then
    BOOT_CONFIG="/boot/config.txt"
fi

if [ -f "$BOOT_CONFIG" ]; then
    cp "$BOOT_CONFIG" "${BOOT_CONFIG}.bak"
    echo "[+] Created backup: ${BOOT_CONFIG}.bak"
    
    # Disable onboard Wi-Fi overlay
    if ! grep -q "dtoverlay=disable-wifi" "$BOOT_CONFIG"; then
        echo "dtoverlay=disable-wifi" >> "$BOOT_CONFIG"
        echo "[+] Added dtoverlay=disable-wifi to $BOOT_CONFIG"
    else
        echo "[+] dtoverlay=disable-wifi already present"
    fi

    # Disable onboard Bluetooth overlay
    if ! grep -q "dtoverlay=disable-bt" "$BOOT_CONFIG"; then
        echo "dtoverlay=disable-bt" >> "$BOOT_CONFIG"
        echo "[+] Added dtoverlay=disable-bt to $BOOT_CONFIG"
    else
        echo "[+] dtoverlay=disable-bt already present"
    fi
else
    echo "[!] Warning: Boot config.txt not found. Skipping hardware overlay edits."
fi

# Stop and disable wireless daemon services if present
systemctl disable --now wpa_supplicant bluetooth hciuart 2>/dev/null || true
rfkill block all 2>/dev/null || true
echo "[+] Wireless interfaces blocked and daemons disabled."

# 5. Configure Static IP 192.168.50.2/24 on Wired Ethernet (eth0)
echo "[4/8] Configuring wired Ethernet static IP (192.168.50.2/24)..."

# Method A: NetworkManager (Standard on Raspberry Pi OS Bookworm)
if command -v nmcli &>/dev/null && systemctl is-active --quiet NetworkManager; then
    echo "[*] Configuring static IP via NetworkManager (nmcli)..."
    nmcli con delete "lifelink-eth0" 2>/dev/null || true
    nmcli con add type ethernet con-name "lifelink-eth0" ifname eth0 \
        ip4 192.168.50.2/24 gw4 192.168.50.1 \
        ipv4.dns "1.1.1.1" ipv4.method manual 2>/dev/null || true
    nmcli con up "lifelink-eth0" 2>/dev/null || true
    echo "[+] NetworkManager connection lifelink-eth0 configured."
fi

# Method B: /etc/network/interfaces.d/eth0 fallback
INTERFACES_D="/etc/network/interfaces.d"
mkdir -p "$INTERFACES_D"
cat << 'EOF' > "$INTERFACES_D/eth0"
# LifeLink 2.0 Dedicated Wired Ethernet Connection to Pi 5
allow-hotplug eth0
iface eth0 inet static
    address 192.168.50.2
    netmask 255.255.255.0
    gateway 192.168.50.1
EOF
echo "[+] Fallback static interface configuration written to $INTERFACES_D/eth0"

# Method C: dhcpcd.conf fallback (for Legacy Bullseye builds)
DHCPCD_CONF="/etc/dhcpcd.conf"
if [ -f "$DHCPCD_CONF" ] && ! grep -q "interface eth0" "$DHCPCD_CONF"; then
    cat << 'EOF' >> "$DHCPCD_CONF"

# LifeLink 2.0 Pi 3B+ Static Wired Ethernet
interface eth0
static ip_address=192.168.50.2/24
static routers=192.168.50.1
EOF
    echo "[+] Fallback static configuration appended to $DHCPCD_CONF"
fi

# 6. Deploy application files to /opt/lifelink-camera
echo "[5/8] Deploying camera application to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"

# Copy python source files, requirements, and diagnostic tools
cp "$SCRIPT_DIR"/*.py "$INSTALL_DIR/"
cp "$SCRIPT_DIR/requirements.txt" "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/verify_camera.py" 2>/dev/null || true

# Determine target non-root user (pi or lifelink)
TARGET_USER="pi"
if ! id "pi" &>/dev/null; then
    if id "lifelink" &>/dev/null; then
        TARGET_USER="lifelink"
    else
        useradd -m -s /bin/bash pi || true
        TARGET_USER="pi"
    fi
fi
echo "[+] Designated service user: $TARGET_USER"

# Configure group permissions for video, gpio, and dialout
usermod -a -G video,gpio,dialout "$TARGET_USER" || true
chown -R "$TARGET_USER:video" "$INSTALL_DIR"
chmod 755 "$INSTALL_DIR"

# 7. Install and enable systemd daemon
echo "[6/8] Installing lifelink-camera.service unit..."
cp "$SCRIPT_DIR/systemd/lifelink-camera.service" /etc/systemd/system/

# Adjust user in systemd unit if different from pi
if [ "$TARGET_USER" != "pi" ]; then
    sed -i "s/^User=pi/User=$TARGET_USER/g" /etc/systemd/system/lifelink-camera.service
fi

systemctl daemon-reload
systemctl enable lifelink-camera.service

# 8. Safe GPIO18 state verification (guarantee LED is strictly OFF)
echo "[7/8] Ensuring GPIO18 850nm IR LED default state is OFF..."
if command -v pinctrl &>/dev/null; then
    pinctrl set 18 op dl || true
    echo "[+] GPIO18 set to OUTPUT LOW (OFF) via pinctrl"
elif command -v raspi-gpio &>/dev/null; then
    raspi-gpio set 18 op dl || true
    echo "[+] GPIO18 set to OUTPUT LOW (OFF) via raspi-gpio"
fi

echo "[8/8] Finalizing verification..."
echo "================================================================="
echo " LifeLink 2.0: Raspberry Pi 3B+ Substation Installation Complete!"
echo " Service is registered: sudo systemctl start lifelink-camera"
echo " Run diagnostic check:   python3 /opt/lifelink-camera/verify_camera.py"
echo " Health check:           curl http://192.168.50.2:5000/health"
echo "================================================================="

