#!/usr/bin/env bash
# ==============================================================================
# LifeLink 2.0 - Raspberry Pi 5 Central Terminal Installation Script
# Target: Raspberry Pi 5 (Debian 12 Bookworm ARM64)
# Configures system packages, virtualenv, udev rules, local database,
# systemd services, and Chromium touchscreen kiosk launcher.
# ==============================================================================

set -euo pipefail

INSTALL_DIR="/opt/lifelink"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "================================================================="
echo " LifeLink 2.0: Raspberry Pi 5 Terminal Deployment"
echo "================================================================="

# 1. Require root privileges
if [ "$EUID" -ne 0 ]; then
    echo "[-] Error: Please run this installer as root (e.g. sudo bash install.sh)"
    exit 1
fi

# 2. Check architecture
echo "[1/8] Verifying hardware platform..."
ARCH="$(uname -m)"
echo "[+] Detected Architecture: $ARCH"
if [[ "$ARCH" != "aarch64" ]]; then
    echo "[!] Warning: Target is expected to be ARM64 (aarch64) Raspberry Pi 5."
    echo "    Proceeding in cross-platform installation mode."
fi

# 3. Install system dependencies via APT
echo "[2/8] Installing system dependencies via APT..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    libpq-dev \
    build-essential \
    curl \
    unclutter \
    x11-xserver-utils \
    chromium-browser \
    sqlite3

# Optional PostgreSQL package installation
if [ "${INSTALL_POSTGRES:-false}" = "true" ]; then
    echo "[*] Installing PostgreSQL server..."
    apt-get install -y postgresql postgresql-contrib
    systemctl enable postgresql
    systemctl start postgresql
fi

# 4. Deploy application files to /opt/lifelink
echo "[3/8] Deploying application tree to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/backend" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/frontend" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/iris-engine" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/protocol" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/sync" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/database" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/kiosk" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/weights" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/requirements.txt" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/verify_installation.py" "$INSTALL_DIR/"
[ -f "$SCRIPT_DIR/lifelink_hardware_diagnostic.py" ] && cp "$SCRIPT_DIR/lifelink_hardware_diagnostic.py" "$INSTALL_DIR/" || true
[ -d "$SCRIPT_DIR/tests" ] && cp -r "$SCRIPT_DIR/tests" "$INSTALL_DIR/" || true
[ -f "$SCRIPT_DIR/README_HARDWARE_DIAGNOSTIC.md" ] && cp "$SCRIPT_DIR/README_HARDWARE_DIAGNOSTIC.md" "$INSTALL_DIR/" || true

# Setup environment configuration
mkdir -p /etc/lifelink
if [ -f "$SCRIPT_DIR/.env" ]; then
    cp "$SCRIPT_DIR/.env" /etc/lifelink/lifelink.env
    cp "$SCRIPT_DIR/.env" "$INSTALL_DIR/.env"
    echo "[+] Deployed production environment to /etc/lifelink/lifelink.env and $INSTALL_DIR/.env"
elif [ ! -f /etc/lifelink/lifelink.env ]; then
    cp "$SCRIPT_DIR/.env.example" /etc/lifelink/lifelink.env
    echo "[+] Created /etc/lifelink/lifelink.env"
fi

# Detect active target user (prioritizes invoking user via sudo, then lifelink, then pi)
TARGET_USER="${SUDO_USER:-$(logname 2>/dev/null || echo ${USER:-lifelink})}"
if [ "$TARGET_USER" = "root" ] || [ -z "$TARGET_USER" ]; then
    if id "lifelink" &>/dev/null; then
        TARGET_USER="lifelink"
    elif id "pi" &>/dev/null; then
        TARGET_USER="pi"
    else
        TARGET_USER="lifelink"
        useradd -m -s /bin/bash lifelink || true
    fi
fi
TARGET_HOME=$(eval echo "~$TARGET_USER")
echo "[+] Target system user: $TARGET_USER (home: $TARGET_HOME)"

# Ensure target user belongs to peripheral device groups
usermod -a -G dialout,video,audio "$TARGET_USER" || true
if getent group render &>/dev/null; then
    usermod -a -G render "$TARGET_USER" || true
fi

chown -R "$TARGET_USER:$TARGET_USER" "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
chmod +x "$INSTALL_DIR/kiosk/kiosk.sh"

# 5. Create Python Virtual Environment
echo "[4/8] Creating Python virtual environment in $INSTALL_DIR/venv..."
if [ ! -d "$INSTALL_DIR/venv" ]; then
    python3 -m venv "$INSTALL_DIR/venv"
fi
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip setuptools wheel
echo "[*] Installing Python dependencies from requirements.txt..."
"$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt"

# Ensure venv permissions
chown -R "$TARGET_USER:$TARGET_USER" "$INSTALL_DIR"

# 6. Install udev rules for ESP32 fingerprint serial host
echo "[5/8] Installing udev rules (99-lifelink.rules)..."
cp "$SCRIPT_DIR/udev/99-lifelink.rules" /etc/udev/rules.d/
udevadm control --reload-rules || true
udevadm trigger || true

# 7. Initialize Database and Seed Default Staff Accounts
echo "[6/8] Initializing local database tables and initial staff seeds..."
sudo -u "$TARGET_USER" "$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/database/init_db.py"

# 8. Configure and Enable Systemd Services
echo "[7/8] Registering systemd service units..."
cp "$SCRIPT_DIR/systemd/lifelink-backend.service" /etc/systemd/system/
cp "$SCRIPT_DIR/systemd/lifelink-kiosk.service" /etc/systemd/system/

# Dynamically patch systemd units with active target user
sed -i "s/^User=.*/User=$TARGET_USER/g" /etc/systemd/system/lifelink-backend.service
sed -i "s/^Group=.*/Group=$TARGET_USER/g" /etc/systemd/system/lifelink-backend.service
sed -i "s/^User=.*/User=$TARGET_USER/g" /etc/systemd/system/lifelink-kiosk.service
sed -i "s/^Group=.*/Group=$TARGET_USER/g" /etc/systemd/system/lifelink-kiosk.service
sed -i "s|Environment=XAUTHORITY=.*|Environment=XAUTHORITY=$TARGET_HOME/.Xauthority|g" /etc/systemd/system/lifelink-kiosk.service

systemctl daemon-reload
systemctl enable lifelink-backend.service
systemctl enable lifelink-kiosk.service

# 9. Verify Installation
echo "[8/8] Executing installation validation script..."
sudo -u "$TARGET_USER" "$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/verify_installation.py"

echo "================================================================="
echo " LifeLink 2.0: Raspberry Pi 5 Terminal successfully installed!"
echo " Start backend service:  sudo systemctl start lifelink-backend"
echo " Check service health:   curl http://127.0.0.1:5000/api/v1/health"
echo " Kiosk auto-starts on:   graphical login"
echo "================================================================="
