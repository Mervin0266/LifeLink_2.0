#!/usr/bin/env python3
"""
LifeLink 2.0 - Cross-Platform ESP32 Firmware Flashing & Diagnostic Tool
Works on Windows, Linux, and macOS.
Uploads boot.py, framing.py, fplibMicro.py, and main.py to ESP32 using mpremote,
then verifies the connection and GT-521F32 UART response.
"""

import sys
import os
import time
import subprocess
import argparse
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
FIRMWARE_DIR = SCRIPT_DIR.parent / "firmware"


def check_and_install_dependencies():
    """Ensures mpremote, esptool, and pyserial are available."""
    missing = []
    for mod in ["mpremote", "serial"]:
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod if mod != "serial" else "pyserial")

    if missing:
        print(f"[*] Installing required host packages: {', '.join(missing)}...")
        req_file = SCRIPT_DIR.parent / "requirements.txt"
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(req_file)])


def detect_com_port(preferred_port=None):
    """Detects the ESP32 COM/serial port."""
    if preferred_port:
        return preferred_port

    import serial.tools.list_ports
    ports = list(serial.tools.list_ports.comports())
    candidates = []

    print("\n[*] Scanning serial ports on your computer:")
    for p in ports:
        desc = p.description.lower()
        hwid = p.hwid.lower()
        print(f"  - {p.device}: {p.description}")
        # Match common USB-UART bridges: CP210x, CH340, FTDI, or USB Serial
        if any(keyword in desc or keyword in hwid for keyword in ["cp210", "ch340", "ftdi", "usb to uart", "usb serial"]):
            candidates.append(p.device)

    if len(candidates) == 1:
        print(f"\n[+] Auto-detected ESP32 on port: {candidates[0]}")
        return candidates[0]
    elif len(candidates) > 1:
        print(f"\n[!] Multiple candidate ports detected: {candidates}")
        return candidates[0]
    elif ports:
        # Fall back to first non-bluetooth port if available
        non_bt = [p.device for p in ports if "bluetooth" not in p.description.lower()]
        if non_bt:
            return non_bt[0]

    return None


def upload_firmware(port):
    """Uploads firmware files using mpremote."""
    required_files = ["boot.py", "framing.py", "fplibMicro.py", "main.py"]
    for f in required_files:
        f_path = FIRMWARE_DIR / f
        if not f_path.exists():
            print(f"[-] Error: Required file missing: {f_path}")
            return False

    print(f"\n[*] Connecting to ESP32 on {port}...")
    # Test connection and REPL responsiveness
    test_cmd = [sys.executable, "-m", "mpremote", "connect", port, "fs", "ls"]
    ret = subprocess.run(test_cmd, capture_output=True, text=True)
    if ret.returncode != 0:
        print("[-] Could not communicate with MicroPython REPL.")
        print("    Details:", ret.stderr.strip() or ret.stdout.strip())
        print("\n[TIP] If this is a fresh ESP32 without MicroPython installed:")
        print("      1. Download MicroPython generic ESP32 .bin from https://micropython.org/download/esp32/")
        print(f"      2. Run: python -m esptool --port {port} erase_flash")
        print(f"      3. Run: python -m esptool --port {port} write_flash -z 0x1000 <firmware.bin>")
        return False

    print(f"[+] Connected to ESP32! Uploading LifeLink 2.0 firmware files to root filesystem:")
    for f in required_files:
        f_path = FIRMWARE_DIR / f
        print(f"  -> Uploading {f} ({f_path.stat().st_size} bytes)...")
        upload_cmd = [sys.executable, "-m", "mpremote", "connect", port, "fs", "cp", str(f_path), f":{f}"]
        subprocess.check_call(upload_cmd)

    print("\n[*] Soft-resetting ESP32 to launch LifeLink 2.0 firmware daemon...")
    reset_cmd = [sys.executable, "-m", "mpremote", "connect", port, "reset"]
    subprocess.run(reset_cmd, capture_output=True)
    time.sleep(2.0)
    return True


def run_diagnostics(port):
    """Runs test_handshake.py against the ESP32."""
    print(f"\n[*] Running test handshake over {port}...")
    handshake_script = SCRIPT_DIR / "test_handshake.py"
    cmd = [sys.executable, str(handshake_script), "--port", port]
    ret = subprocess.run(cmd)
    return ret.returncode == 0


def main():
    parser = argparse.ArgumentParser(description="LifeLink 2.0 ESP32 Firmware Flashing Tool")
    parser.add_argument("--port", "-p", default=None, help="Serial COM port (e.g., COM5 on Windows or /dev/ttyUSB0 on Linux)")
    parser.add_argument("--install-micropython", action="store_true", help="Erase and flash base MicroPython firmware binary")
    parser.add_argument("--bin", default=None, help="Path to MicroPython firmware .bin file")
    args = parser.parse_args()

    print("=================================================================")
    print(" LifeLink 2.0: ESP32 Firmware Flashing & Diagnostic Tool")
    print("=================================================================")

    check_and_install_dependencies()

    port = detect_com_port(args.port)
    if not port:
        print("\n[-] Error: No ESP32 serial port detected.")
        print("    1. Plug your ESP32 into a USB port on this laptop.")
        print("    2. If needed, install the CP210x or CH340 USB-to-UART driver for Windows.")
        print("    3. Check Windows Device Manager -> Ports (COM & LPT).")
        print("    4. Re-run: python flash.py --port COMx")
        sys.exit(1)

    print(f"[+] Selected Port: {port}")

    if args.install_micropython:
        if not args.bin:
            print("[-] Please specify the path to the MicroPython .bin file with --bin <path>")
            sys.exit(1)
        print(f"[*] Erasing flash on {port}...")
        subprocess.check_call([sys.executable, "-m", "esptool", "--port", port, "erase_flash"])
        print(f"[*] Writing MicroPython binary: {args.bin}...")
        subprocess.check_call([sys.executable, "-m", "esptool", "--port", port, "--chip", "esp32", "write_flash", "-z", "0x1000", args.bin])
        time.sleep(2.0)

    # Upload files
    ok = upload_firmware(port)
    if not ok:
        sys.exit(1)

    # Run verification handshake
    verified = run_diagnostics(port)
    if verified:
        print("\n=================================================================")
        print(" SUCCESS! LifeLink 2.0 ESP32 firmware is installed and verified.")
        print(f" Port: {port} | Status: READY (Safe Idle, Scan Invariant Verified)")
        print(" You can now connect this ESP32 to the Raspberry Pi 5.")
        print("=================================================================")
    else:
        print("\n[!] Firmware uploaded, but handshake verification failed.")
        print("    Check UART wiring between ESP32 and GT-521F32 (RX: GPIO16, TX: GPIO17).")


if __name__ == "__main__":
    main()
