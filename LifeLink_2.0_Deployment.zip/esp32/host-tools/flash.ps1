# LifeLink 2.0 - Windows PowerShell Flasher Launcher
param (
    [string]$Port = ""
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($Port -ne "") {
    python "$ScriptDir\flash.py" --port $Port
} else {
    python "$ScriptDir\flash.py"
}
